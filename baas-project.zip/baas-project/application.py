from flask import Flask, render_template, request, send_file, abort
from web3 import Web3, EthereumTesterProvider
import hashlib
from models import *
import os
from datetime import date, datetime, timedelta
import time
import threading
from flask_table import Table, Col, create_table

app=Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"]=os.getenv("SQLALCHEMY_DATABASE_URI")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"]=False
db.init_app(app) 
UPLOAD_FOLDER='./uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
global passwd
global infura_url
loggedin=-1

def main():
    db.create_all()

if __name__ == "__main__":
    with app.app_context():
        main()

@app.route('/thr')
def allthreads():
    th=threads.query.get(1)
    return (f"{th.sch_id} {th.thread_id}")

class TableCls(Table):
    id = Col('PaymentID')
    payerid = Col('Payer\'s ID')
    recipientid = Col('Recipient\'s ID')
    amount = Col('Amount')
    scheduled_time = Col('Scheduled Time')

def getkeydict(keystore, id_):
    dict1=keyDict(userid=id_, address=keystore['address'], 
    cipher=keystore['crypto']['cipher'], iv=keystore['crypto']['cipherparams']['iv'], 
    ciphertext=keystore['crypto']['ciphertext'],kdf=keystore['crypto']['kdf'], 
    dklen=keystore['crypto']['kdfparams']['dklen'],n=keystore['crypto']['kdfparams']['n'], 
    r=keystore['crypto']['kdfparams']['r'],p=keystore['crypto']['kdfparams']['p'],
    salt=keystore['crypto']['kdfparams']['salt'], mac=keystore['crypto']['mac'],
    id_=keystore['id'] , version= keystore['version'])
    return dict1

def keyfromdict(key_dict):
    keystore={}
    keystore['address']=key_dict.address,
    keystore['crypto']={}
    keystore['crypto']['cipher']=key_dict.cipher,
    keystore['crypto']['cipherparams']={},
    keystore['crypto']['cipherparams'][iv]=key_dict.iv,
    keystore['crypto']['ciphertext']=key_dict.ciphertext,
    keystore['crypto']['kdf']=key_dict.kdf,
    keystore['crypto']['kdfparams']={},
    keystore['crypto']['kdfparams']['dklen']=key_dict.dklean,
    keystore['crypto']['kdfparams']['n']=key_dict.n,
    keystore['crypto']['kdfparams']['r']=key_dict.r,
    keystore['crypto']['kdfparams']['p']=key_dict.p,
    keystore['crypto']['kdfparams']['salt']=key_dict.salt,
    keystore['crypto']['mac']=key_dict.salt,
    keystore['id']=key_dict.id_,
    keystore['version']=key_dict.version
    return keystore

def wait(dict_ ):
    fromid=dict['fromid']
    toid=dict_[toid]
    val=dict_[val]
    hrs=dict_[hrs]
    sch_id=dict_[sch_id]
    newth=threads(sch_id=sch_id, thread_id=threading.get_ident())
    db.session.add(newth)
    db.session.commit()

    time.sleep(hrs*3600)
    flag=1
    try:
        txnhash=w3.eth.sendTransaction({'from':str(w3.eth.accounts[0]),'to':str(toid),'value': str(val)}) 
        txnhash=str(txnhash.hex())
        scheduledpayment=scheduled.query.get(sch_id)
        paid=payHistory(payerid=fromid, recipientid=toid, amount=val, payment_datetime=datetime.now(), txnhash=txnhash)
        tid=paid.id
    except:
        flag=-1

    if flag==1:
        return str(txnhash)
    else:
        return "Sorry, that didn't work."

def quotechange(str_):
    str_=str(str_)
    strnew=""
    for i in range(0, len(str_)):
        if str_[i] is '\'':
            strnew+='\"'
        else:
            strnew+=str_[i]
    return strnew

def count(num):
    lst=[]
    for i in range(0,num):
        lst.append([])
    return lst

def loginfn(infura_url, passwd, keystore):
    acc={}
    val=1
    w3=Web3(Web3.HTTPProvider(infura_url))
    try:
        acc=w3.eth.account.decrypt(keystore, passwd)
    except ValueError:
        print("Wrong password")
        val=-1
    finally:
        return acc,val

@app.route('/')
@app.route('/signup')
def signup():
    return render_template("createaccount.html", retry =False)

@app.route('/loggedinf')
def loggedinf():
    global loggedin
    return str(loggedin)

@app.route('/checksignup', methods=["GET", "POST"])
def checksignup(): 
    global loggedin 

    if request.method=="GET":
        return "Please fill the form"
    else:
        flag=1
        first=request.form.get("first")
        last=request.form.get("last")
        phone_no=request.form.get("phone_no")
        aadhar=request.form.get("aadhar")
        infura_key=request.form.get("infura_key")
        email=request.form.get("email")
        passwd=str(request.form.get("passwd"))
        passwdhash=hashlib.md5(passwd.encode()).hexdigest()

        if first is "" or last is "" or phone_no is "" or aadhar is "" or infura_key is "" or email is "" or passwd is "":
            return render_template("createaccount.html", retry =True)  
        # if not(User.query.filter_by().first() is None)        

        if flag is 1:
            infura_url='https://mainnet.infura.io/v3/'+infura_key
            w3=Web3(Web3.HTTPProvider(infura_url))
            account = w3.eth.account.create()
            keystore=account.encrypt(passwd)

            # keystore=str(keystore)
            # keystorehash = hashlib.md5(keystore.encode())
            # keystorehash=keystorehash.hexdigest()
            
            u=User(first=first, last=last, phone_no=phone_no, email=email, aadhar=aadhar, addr=account.address, lastlogin=date.today(), infurakey=infura_key, passwdhash=str(passwdhash))
            db.session.add(u)
            db.session.commit()
            loggedin=fromid=u.id
            
            key_dict=getkeydict(keystore, fromid)
            db.session.add(key_dict)
            db.session.commit()

            return render_template("accountcreated.html",fromid=fromid , first=first, keystore=keystore)

@app.route('/deleteall')
def deleteall():
    User.query.delete()
    db.session.commit()
    # db.create_all()
    return "hey"

@app.route('/ll')
def ll():
    list_="ab"
    ths=threads.query.all()
    for th in ths:
        list_+=(f"{th.sch_id} {th.thread_id} ")
    return list_

@app.route('/showall')
def showall():
    lst=""
    us=User.query.all()
    for u in us:
        lst+=(f"{u.first} {u.last} {u.id } {u.passwdhash} ")
    return lst


@app.route('/login')
def login():
    if request.method is "GET":
        val=1
    else:
        val=-1
    return render_template("login.html", val=val)

@app.route('/checklogin', methods=["POST"])
def checklogin():
    global loggedin
    id_=request.form.get("id_")
    passwd=str(request.form.get("passwd"))
    passhash=(hashlib.md5(passwd.encode())).hexdigest()

    user=User.query.filter_by(id=id_).first()
    if user is None:
        return render_template("login.html", val=0)
        # return render_template("login.html", retry=-1)
    elif user.passwdhash==passhash:
            loggedin=id_
            return render_template("home.html",fromid=id_, first=user.first)
    else:
        return render_template("login.html", val=-1)
        # return render_template("login.html", retry=-1)

    # else:
    #     first_=user.first
    #     diff=0
    #     d2=user.lastlogin
    #     d1=date.today()
    #     delta=d2-d1
    #     diff=delta.days

    #     if diff>=2:
    #         return render_template("setupaccount.html", val=1)
    #     else:
    #         return render_template("home.html", fromid=id_)

@app.route('/home',methods=["GET", "POST"])
def home():
    global loggedin
    if request.method=="GET":
        return "Please login first"
    else:
        first=request.form.get("first")
        fromid=loggedin
        if first is None or fromid is None:
            return abort(404)
        else:
            return render_template("home.html", first=first, fromid=fromid)

@app.route('/paynow', methods=["POST", "GET"])
def paynow():
    global loggedin
    if request.method=="GET":               #if directly via address bar
        idnum=request.args.get('abc')
        if idnum is None:
            return "No such field."
        else:
            user=User.query.filter_by(id=id_).first()
            if user is None:                    #id passed in address bar doesn't match
                return "No such user."
            else:
                d2=user.lastlogin
                d1=date.today()
                delta=d2-d1
                diff=delta.days
                if diff>=2:
                    return render_template("login.html", val=1)  #time to setup wallet again
                else:
                    return render_template("paynow.html", numtxn=1)     #by default, pay to one account only
    else:
        fromid=loggedin
        # numtxn=request.form.get("numtxn")
        numtxn=1
        numtxn=int(numtxn)
        return render_template("paynow.html",numtxn=numtxn, fromid=fromid) #numtxn transactions allowed, via post method request

@app.route('/payscheduler', methods=["POST"])
def payscheduler():
    global loggedin
    fromid=loggedin
    numtxn=request.form.get("numtxn")
    numtxn=1
    numtxn=int(numtxn)
    return render_template("payscheduler.html",numtxn=numtxn, fromid=fromid) #numtxn transactions allowed, via post method request

@app.route('/paymentvalid_now',methods=["POST"])
def paymentvalid_now():

    global loggedin
    txhash="hash"
    toid=request.form.get("toid")
    amount=request.form.get("Amount")
    fromid=loggedin
    u=User.query.get(fromid)
    if User.query.get(toid) is None or fromid is toid:
        return "Invalid account"

    flag=1
    w3=Web3(Web3.EthereumTesterProvider())    
    if int(amount)>0:
        # web3=Web3(Web3.HTTPProvider(infura_url))
        # keystore=str(keystore)
        # acc=web3.eth.account.decrypt(keystore, passwd)
        # fromaddr=acc.address
        first=User.query.get(fromid)
        return render_template("confirmPayNow.html",fromid=fromid, toid=toid, val=amount, first=first)

@app.route('/paymentvalid_later',methods=["POST"])
def paymentvalid_later():

    global loggedin
    txhash="hash"
    toid=request.form.get("toid")
    amount=request.form.get("Amount")
    fromid=loggedin
    if User.query.get(fromid) is None or User.query.get(toid) is None or fromid is toid:
        return "Invalid operation "+str(fromid) +' '+str(toid)

    flag=1
    if int(amount)>0:
        # web3=Web3(Web3.HTTPProvider(infura_url))
        # keystore=str(keystore)
        # acc=web3.eth.account.decrypt(keystore, passwd)
        # fromaddr=acc.address

        hrs=int(request.form.get("Hours"))
        if(hrs<0 or hrs>24):
            return "Sorry, that didn't work. Schedule time invalid."
        else:
            first=User.query.get(fromid)
            return render_template("confirmPayLater.html",fromid=fromid, toid=toid, val=amount,first=first , hrs=hrs)
    else:
        return "Invalid amount"


@app.route('/confirmedpaynow', methods=["POST"])
def confirmedpaynow():
    fromid=request.form.get("fromid")
    toid=request.form.get("toid")
    val=request.form.get("val")

    try:
        w3=Web3(Web3.EthereumTesterProvider())    
        txnhash=w3.eth.sendTransaction({'to': '0xd3CdA913deB6f67967B99D67aCDFa1712C293601', 'from': w3.eth.coinbase, 'value': 12345})
        txnhash=str(txnhash.hex())
        paid=payHistory(payerid=fromid, recipientid=toid, amount=val, payment_date=date.today(), payment_time=time.now(), txnhash=txnhash)
        db.session.add(paid)
        db.session.commit()
        tid=paid.id     #later use maybe
    except:
        flag=-1

    if flag==1:
        return str(txnhash)
    else:
        return "Sorry, that didn't work."

@app.route('/confirmedPayLater', methods=["POST"])
def confirmedpaylater():
    fromid=request.form.get("fromid")
    toid=request.form.get("toid")
    val=request.form.get("val")
    hrs=int(request.form.get("hrs"))

    scheduledpayment=scheduled(payerid=fromid, recipientid=toid, amount=val,scheduled_time=datetime.now()+timedelta(hours=hrs) )
    db.session.add(scheduledpayment)
    db.session.commit()
    sch_id=scheduledpayment.id
    dict_={'fromid':fromid, 'toid':toid, 'val':val, 'hrs':hrs, 'sch_id':sch_id}
    t = threading.Thread(name='wait', target=wait, args=[dict_])
    t.start()
    return str(sch_id)

@app.route('/viewScheduled', methods=["GET","POST"])
def viewScheduled():
    global loggedin

    id_=loggedin
    # return str(id_)
    items=scheduled.query.filter_by(payerid=id_)

    tableclsobj=TableCls(items)
    tableclsobj.border=True
    return render_template('results.html', table=tableclsobj)